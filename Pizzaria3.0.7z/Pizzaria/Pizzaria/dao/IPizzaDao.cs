﻿using System;
namespace Pizzaria.dao
{
    public interface IPizzaDao
    {
        void Adicionar(Pizzaria.modelo.Pizza pizza);
        void Atualizar(Pizzaria.modelo.Pizza pizza);
        Pizzaria.modelo.Pizza BuscarPorId(long id);
        System.Collections.Generic.List<Pizzaria.modelo.Pizza> BuscarPorSabor(string sabor);
        System.Collections.Generic.List<Pizzaria.modelo.Pizza> BuscarTodas();
        void Remover(Pizzaria.modelo.Pizza pizza);
    }
}
