﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzaria.dao
{
    public class PizzaDaoMySQL : IPizzaDao
    {
        public void Adicionar(modelo.Pizza pizza)
        {
            throw new NotImplementedException();
        }
        
        public void Atualizar(modelo.Pizza pizza)
        {
            throw new NotImplementedException();
        }

        public modelo.Pizza BuscarPorId(long id)
        {
            throw new NotImplementedException();
        }

        public List<modelo.Pizza> BuscarPorSabor(string sabor)
        {
            throw new NotImplementedException();
        }

        public List<modelo.Pizza> BuscarTodas()
        {
            throw new NotImplementedException();
        }

        public void Remover(modelo.Pizza pizza)
        {
            throw new NotImplementedException();
        }
    }
}
