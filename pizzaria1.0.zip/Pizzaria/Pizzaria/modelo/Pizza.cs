﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzaria.modelo
{
    public class Pizza
    {
        public long IdPizza { get; set; }
        public String Sabor { get; set; }
        public decimal Valor { get; set; }
    }
}
